#pragma once
/*This is our class file where we build our class that we will make objects to use from.
Prototype functions*/
class ClassFindWater
{
public:
	int FindWaterScenario(); // it starts water scenario.

private:
	int playersScore;
}; 
