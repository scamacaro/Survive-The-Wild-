#pragma once
/*This is our class file where we build our class that we will make obects to use from.
Prototype functions*/

class ClassFindFood
{
public:
	int FindFoodScenario(); // it starts food scenario.

private:
	int playersScore;
};

