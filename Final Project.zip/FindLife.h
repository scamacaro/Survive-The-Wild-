#pragma once
/*This is our class file where we build our class that we will make objects to use from.
Prototype functions*/
class ClassFindLife
{
public:
	int FindIntelligentLifeScenario(); // it starts shelter/life scenario.

private:
	int playersScore;
};